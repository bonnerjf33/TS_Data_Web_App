"""Metadata for the mpld3 package."""
__version__ = '0.3'
