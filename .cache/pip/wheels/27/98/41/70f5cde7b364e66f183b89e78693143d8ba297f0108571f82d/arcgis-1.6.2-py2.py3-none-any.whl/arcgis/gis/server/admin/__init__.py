"""
Administrative Manager Classes
"""
from __future__ import print_function
from .administration import Server
